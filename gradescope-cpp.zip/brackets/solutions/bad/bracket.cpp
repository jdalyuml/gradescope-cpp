// Copyright 2023 Jaeda
#include "bracket.hpp"

#include <stack>

bool isMatched(const std::string& line){
    return false;
}
