// Copyright 2023 Jaeda
#include "bracket.hpp"

#include <stack>

bool ismatched(const std::string& line) {
    return false;
}
