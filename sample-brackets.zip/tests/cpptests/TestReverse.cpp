// Copyright 2023 Dr. Daly
#include "common.hpp"

BOOST_AUTO_TEST_CASE(TestReverse) {
    BOOST_REQUIRE_EQUAL(isMatched("><"), false);
}
